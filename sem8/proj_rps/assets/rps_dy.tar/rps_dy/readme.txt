
------------------------------------------------------
  Robotic Pesticide Sprayer : Software install guide
------------------------------------------------------
	version 1.2 
		Date : 2022/06/11 [yyyy/mm/dd]
------------------------------------------------------


   Clients currently only for unix systems 
   
   	OS X (Apple Mac)
   	Linux
   		debian
   		ubuntu
   		redhat
   		fedora
   		alpine
   		arch
   		.... other linux distributions
   	FreeBSD
   	Solarious
   	.... other UNIX Systems
   		
   		
   Windows Client ( under Development )
   		

----------------------------------------------------------------

	For building Server : arduino (robot itself)
	
		Arduino GUI
			open sketch "rps_ard" 
			then verfiy and upload on Arduino UNO
			
		Arduino CLI
			read arduino cli manual to select port and use arduino cli
			then run the below command in terminal
			"arduino --upload rps_ard/rps_ard.ino"

----------------------------------------------------------------

   --------------------------------------------
   
	for building Client
	
	
	
	
		Prerequisite
		
			For debian		
				apt install g++ gcc clang libx11-dev
				apt install xterm bluez bluetooth
			
			For other UNIX
				install these packages 
					package name may be different
					you can find out on your UNIX system manual 
			
			
			Additional you need to install serial library from github
			( download zip from github , compile and install )
			
				CppLinuxSerial
					https://github.com/gbmhunter/CppLinuxSerial
		
		
		
		Compiling
			
			first know your robot bluetooth address
			turn on your robot 
			run commands
				"bluetoothctl"
				"power on"
				"scan on"
				"exit"
			
			then copy bluetooth address
				e.g. 12:12:12:12:12:XY
				address will be shown with name like HC-05
				but we need address only
			
			then edit file "c/usr/bin/auto.sh"
				then change the bluetooth address in the file 
				to your robot's bluetooth address
			
			then run below commands in terminal
			
			------------------------
				cd c
				chmod +x mk
				./mk
				cd ..
			------------------------
			
			all done client is compiled
			
		Running Client
			
			after compiling 
			
			
			
			
			open a terminal and run commad
			"bluetoothctl"
			
			then run below commands in new terminal
			"chmod +x ./c/build/usr/bin/auto.sh"
			"./c/build/usr/bin/auto.sh"
			then enter root password
			
			then in first terminal 
			it will ask for pairing
			then pair
				hint: default passkey for HC-05 is 1234
		
			
			now all done client is running
			
			
			you can now also use desktop entry for easy use 
			copy "./c/build/usr/share/awnto_rps.desktop" to your desktop
			then edit copied file
			then on line Exec=x/x/x/x.sh
			change it to your full path 
			like "/home/user/rps_dy/c/build/usr/bin/auto.sh"
			
		
			
		Using Client with controls
		
		
			First turn on your Robot 
			
			run "usr/bin/auto.sh"
			or execute desktop entry
			then enter root password
			
			when you run rps client you will see 3 differents windows
			 1)	gives information about client
			 2)	gives information about server(robot)
			 3)	a black small window for input
			 
			----------------------------
				Controls
			----------------------------
			  w	to move rps forward
			  s	to move rps backward
			  a	rotate front wheels to left
			  d	rotate front wheels to right
			  space	  apply breaks
			  
			  arrow(left)	same as 'a'
			  arrow(right)	same as 'd'
			  
			  g	toggle grab_ws mode
			  		in this mode you don't need to continue press w,s key
			  f	toggle force mode
			  		in this mode rps will move with force
			  		(not recommanded arduino keep crashing in this mode)
			  
			  q	spin rps left
			  e	spin rps right
			  
			  l	toggle pump
			  
			  
			  y	move arm left
			  u	move arm right
			  
			  pageup	same as 'y'
			  pagedown	same as 'u'
			  
			  
			  r	move nozzle upwards
			  t	move nozzle downwards
			  
			  arrow(up)	same as 'r'
			  arrow(down)	same as 't'
			
			----------------------------
			 
			 
----------------- end of file -------------
			
		
		
		
			
