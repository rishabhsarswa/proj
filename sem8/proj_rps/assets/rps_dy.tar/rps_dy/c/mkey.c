
// USES KEYBOARD KEY TO RESIZE A WINDOW

// Compile : gcc -o go key_and_win.c -lX11

#include <X11/Xlib.h>

#include "mkeyl.h"
#include "patch_linux.h"


int main()
{
	
	
	ax_setup();	
	
	
    Display *d;
    Window window;
    XEvent event, ev;
    int s;

    /* open connection with the server */
    d = XOpenDisplay(NULL);
    if (d == NULL)
    {
        fprintf(stderr, "Cannot open d\n");
        exit(1);
    }

    s = DefaultScreen(d);

    /* create window */
    window = XCreateSimpleWindow(d, RootWindow(d, s), 10, 10, 200, 200, 1,
                           BlackPixel(d, s), BlackPixel(d, s));

    /* select kind of events we are interested in */
    XSelectInput(d, window, StructureNotifyMask | ExposureMask | KeyPressMask | KeyReleaseMask );

    /* map (show) the window */
    XMapWindow(d, window);

    /* event loop */
    while (1)
    {
        //XNextEvent(d, &event);
	
	
    	if ( XCheckMaskEvent(d , ExposureMask | KeyPressMask | KeyReleaseMask  ,&event) )
    	{


		struct ax_keyst *atd = ax_get_axk(event.xkey.keycode);
		if(atd)
		{

    	    		/* keyboard events */
    	    
    	    		if (event.type == KeyPress)
    	    		{
    	    		
    	    			/*
				if( (*atd).is_actd == 1 )
				{
					gettimeofday(&((*atd).cact) , NULL );
    	        			long ppsec = (*atd).cact.tv_sec - (*atd).lact.tv_sec ;
    	        			long ppusec = ppsec*1000000 + (*atd).cact.tv_usec - (*atd).lact.tv_usec ;
    	        			printf( "v:%x;usec:%ld;\n", event.xkey.keycode , ppusec );         
    	        		
				
				}
				else
				*/
				if( (*atd).is_actd == 0 )
				{
					printf( "v:%c;\n", (*atd).scode );
					(*atd).exit_send_remain = 4 ;
					//ax_wr_bt((*atd).scode, 1 );
					//gettimeofday(&((*atd).sact) , NULL );
					
				}	
    	        		gettimeofday(&((*atd).lact) , NULL );
    	        
    	        		(*atd).is_actd = 1 ;
				(*atd).ev_ac = 1 ;
				
				
		
		
    	        		
    	    		}
    	    		else if (event.type == KeyRelease)
    	    		{
    	    	
    	    			//gettimeofday(&((*atd).cact) , NULL );
    	        		//long ppsec = (*atd).cact.tv_sec - (*atd).lact.tv_sec ;
    	        		//long ppusec = ppsec*1000000 + (*atd).cact.tv_usec - (*atd).lact.tv_usec ;
    	        		//printf( "^:%x;usec:%ld;\n", event.xkey.keycode , ppusec );
    	        		
    	        		//printf( "^:%x;\n", event.xkey.keycode );         
    	        		gettimeofday(&((*atd).lact) , NULL );
    	        		
    	        		(*atd).ev_ac = 0 ;
				
    	        		
    	    		}
    	    	}
    	    	else if (event.type == KeyPress)
    	    	{
    	    		printf(">>xcode:%d;\n",event.xkey.keycode);
    	    		/* exit on ESC key press */
    	        	if ( event.xkey.keycode == 0x09 )
    	        		   break;
    	    	}
    	    	
    	 }
    	 
	 ax_loop();
    	 //ax_setuped();
    }
	
    	/* close connection to server */
    	ax_crush();
    	XCloseDisplay(d);
	
    return 0;
}


