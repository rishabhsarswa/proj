#!/bin/bash


cd $(dirname $0)

pwd


rm -rvf c/build


cd ..

zip -r rps_dy.zip rps_dy

tar -cvf rps_dy.tar rps_dy

echo "--- done ---"

