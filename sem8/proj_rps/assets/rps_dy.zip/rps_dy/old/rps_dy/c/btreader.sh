#!/bin/bash


echo ">>> connecting ..."

echo $$ > btreader.pid


while(( 1 == 1 ))
do
	cat /dev/rfcomm0
	echo ">>> retrying ...."
	sleep 2
done




