

struct motor_c_st
{
	char in1 ;
	char in2 ;
	char pwm ;
	
	
	char speed ;
	char motion ;

};

void rps_move_ford(struct motor_c_st &mot);
void rps_move_back(struct motor_c_st &mot);
void rps_move_none(struct motor_c_st &mot);
void rps_move_break(struct motor_c_st &mot);
void rps_move_speed(struct motor_c_st &mot , uint8_t speed);


void rps_pis_autocontrol();


// -----------------


uint8_t rps_move_inisp = 100 ;
uint8_t rps_move_max = 200 ;

struct motor_c_st mot_la;
struct motor_c_st mot_ra;

Servo ser_l; // servo left wheel
Servo ser_r;
char ser_l_off = -15 ;//-15;  // servo offset
char ser_r_off = -10;



char moto_set = 0 ; // motor motion 0 = none ;1 =ford;2=back;3=break;
char moto_set_last = 0 ; // motor motion last
char moto_go_last = 0 ; // motor motion last
char moto_set_ltm = 0 ; // last t motion for grab_ws

char roto_set = 0 ; // rotation 0 = none ;1 =left;2=right;
char roto_set_last = 0 ;



uint8_t moto_go_speed = 0 ;




char ax_sett_forcemode = 0 ;
char ax_sett_verbose = 0 ;
char ax_sett_grab_ws = 0 ;
char ax_sett_pump_lock = 0 ;

struct motor_c_st mot_tbase; //motor arm base
char mot_tbase_inisp = 200 ;
char troto_set = 0 ; // arm base rotation 0 = none ;1 =left;2=right;
char troto_set_last = 0 ;


Servo ser_ttop; // servo arm top
char ser_ttop_off = 10;
int16_t ser_ttop_cur = 0;
char ttroto_set = 0 ; // arm top rotation 0 = none ;1 =up;2=down;
char ttroto_set_last = 0 ;
void ser_ttop_write(int16_t val){ ser_ttop.write(val);ser_ttop_cur=val; }




char ax_pin_pump = 4 ;
char mspin_set = 0 ; // spin the rps

void rps_pis_setup()
{

	
	mot_la.in1 = 13 ;
	mot_la.in2 = 12 ;
	mot_la.pwm = 11 ;
	
	mot_ra.in1 = 7 ;
	mot_ra.in2 = 8 ;
	mot_ra.pwm = 3 ;
	
	
	pinMode(mot_la.in1, OUTPUT);
	pinMode(mot_la.in2, OUTPUT);	

	pinMode(mot_ra.in1, OUTPUT);
	pinMode(mot_ra.in2, OUTPUT);	
	
	
	rps_move_speed(mot_la,0);	
	rps_move_none(mot_la);
	
	
	rps_move_speed(mot_ra,0);	
	rps_move_none(mot_ra);
	
	
	ser_l.attach(6);
	ser_l.write(ser_l_off + 90);
	
	ser_r.attach(9);
	ser_r.write(ser_r_off + 90);
	
	
	mot_tbase.in1 = A2 ;
	mot_tbase.in2 = A3 ;
	mot_tbase.pwm = 5 ;
	
	
	pinMode(mot_tbase.in1, OUTPUT);
	pinMode(mot_tbase.in2, OUTPUT);	
	
	rps_move_speed(mot_tbase,0);	
	rps_move_none(mot_tbase);
	
	
	
	ser_ttop.attach(A5);
	ser_ttop_write(ser_ttop_off + 90);
	
	
	
	pinMode(ax_pin_pump, OUTPUT);	
	
	
}

void rps_pis_loop()
{

	
	char ipos_w = ax_get_ipos('w') ;
	char ipos_x = ax_get_ipos('x') ;
	char ipos_s = ax_get_ipos('s') ;
	
	if( ax_kv[ipos_s].val == 1 || ( ax_kv[ipos_w].val == 1 && ax_kv[ipos_x].val == 1 )  )
	{
		moto_set=3;
		moto_set_ltm = 0 ;
	}
	else if( ax_kv[ipos_w].val == 1   )
	{
		moto_set=1;
		moto_set_ltm = 1 ;
	}
	else if( ax_kv[ipos_x].val == 1   )
	{
		moto_set=2;
		moto_set_ltm = 2 ;
	}
	else if( ax_sett_grab_ws == 1 )
	{
		moto_set = moto_set_ltm ;
	}
	else
	{
		moto_set=0;
		
	}
	
	
	
	char ipos_a = ax_get_ipos('a') ;
	char ipos_d = ax_get_ipos('d') ;
	
	if( ( ax_kv[ipos_a].val == 1 && ax_kv[ipos_d].val == 1 )  )
	{
		roto_set=0;
	}
	else if( ax_kv[ipos_a].val == 1   )
	{
		roto_set=1;
	}
	else if( ax_kv[ipos_d].val == 1   )
	{
		roto_set=2;
	}
	else
	{
		roto_set=0;
		
	}
	
	
	
	
	char ipos_y = ax_get_ipos('y') ;
	char ipos_u = ax_get_ipos('u') ;
	
	if( ( ax_kv[ipos_y].val == 1 && ax_kv[ipos_u].val == 1 )  )
	{
		troto_set=0; //none
	}
	else if( ax_kv[ipos_y].val == 1   )
	{
		troto_set=1; // left
	}
	else if( ax_kv[ipos_u].val == 1   )
	{
		troto_set=2; //right
	}
	else
	{
		troto_set=0;
		
	}
	
	
	
	char ipos_r = ax_get_ipos('r') ;
	char ipos_t = ax_get_ipos('t') ;
	
	if( ( ax_kv[ipos_r].val == 1 && ax_kv[ipos_t].val == 1 )  )
	{
		ttroto_set=0; //none
	}
	else if( ax_kv[ipos_r].val == 1   )
	{
		ttroto_set=1; // up
	}
	else if( ax_kv[ipos_t].val == 1   )
	{
		ttroto_set=2; // down
	}
	else
	{
		ttroto_set=0;
		
	}
	
	
	
	
	char ipos_q = ax_get_ipos('q') ;
	char ipos_e = ax_get_ipos('e') ;
	
	if( ( ax_kv[ipos_q].val == 1 && ax_kv[ipos_e].val == 1 )  )
	{
		mspin_set=0; //none
	}
	else if( ax_kv[ipos_q].val == 1   )
	{
		mspin_set=1; // left
	}
	else if( ax_kv[ipos_e].val == 1   )
	{
		mspin_set=2; // right
	}
	else
	{
		mspin_set=0;
		
	}
	if( moto_set != 0 || roto_set != 0 )
	{
		mspin_set=0;
	}
	
	
	
	char ipos_f = ax_get_ipos('f') ;
	if( ax_kv[ipos_f].lval == 1 && ax_kv[ipos_f].val == 2   )
	{
		if(ax_sett_forcemode == 0)
		{
			sprintf(buff, "> set forcemode");
			ax_alert(buff);
			ax_sett_forcemode = 1 ;
		
		}
		else
		{
			sprintf(buff, "> off forcemode");
			ax_alert(buff);
			ax_sett_forcemode = 0 ;
			ax_sett_grab_ws = 0 ;
		
		}
	}
	char ipos_v = ax_get_ipos('v') ;
	if( ax_kv[ipos_v].lval == 1 && ax_kv[ipos_v].val == 2   )
	{
		if(ax_sett_verbose == 0)
		{
			ax_sett_verbose = 1 ;
			sprintf(buff, "> set verbose");
			ax_alert(buff);
		
		}
		else
		{
			sprintf(buff, "> off verbose");
			ax_alert(buff);
			ax_sett_verbose = 0 ;
		
		}
	}
	
	
	char ipos_g = ax_get_ipos('g') ;
	if( ax_kv[ipos_g].lval == 1 && ax_kv[ipos_g].val == 2   )
	{
		if(ax_sett_grab_ws == 0)
		{
			sprintf(buff, "> set grab_ws");
			ax_alert(buff);
			ax_sett_grab_ws = 1 ;
			moto_set_ltm = 0 ;
			
		}
		else
		{
			sprintf(buff, "> off grab_ws");
			ax_alert(buff);
			ax_sett_grab_ws = 0 ;
		
		}
	}
	
	
	char ipos_l = ax_get_ipos('l') ; //  ckpump
	if( ax_kv[ipos_l].lval == 1 && ax_kv[ipos_l].val == 2   )
	{
		if(ax_sett_pump_lock == 0)
		{
			sprintf(buff, "> set pump");
			ax_alert(buff);
			ax_sett_pump_lock = 1 ;
			
			digitalWrite(ax_pin_pump, HIGH);
			
			
		
		}
		else
		{
			sprintf(buff, "> off pump");
			ax_alert(buff);
			ax_sett_pump_lock = 0 ;
			
			
			
			digitalWrite(ax_pin_pump, LOW);
			
			
		
		}
	}
	
	
	
}
void rps_move_aspeed(char speed)
{

	if( roto_set == 0)
	{
			rps_move_speed(mot_la,speed);
			rps_move_speed(mot_ra,speed);
	}
	else if( roto_set == 1)//left
	{
			rps_move_speed(mot_la, rps_move_inisp - 20 );
			//rps_move_speed(mot_la,0);
			rps_move_speed(mot_ra,speed);
	}
	else if( roto_set == 2)//right
	{
			rps_move_speed(mot_la,speed);
			rps_move_speed(mot_ra, rps_move_inisp - 20 );
			//rps_move_speed(mot_ra, ( (int16_t)speed*10 )/50 );
	}
	
	
	
	
}
void rps_pis_autocontrol()
{

	if( moto_set==3 )
	{
		
		if( moto_set_last != 3 )
		{
			sprintf(buff, "> move break");
			ax_alert(buff);
		
			//rps_move_speed(rps_move_inisp);
			moto_go_speed = 0 ;
			
			
			rps_move_break(mot_la);
			rps_move_break(mot_ra);
			
		}
	}
	else if( moto_set==1   )
	{
		if( moto_set_last != 1 )
		{
			sprintf(buff, "> move ford");
			ax_alert(buff);
		
			//rps_move_speed(rps_move_inisp);
			
			rps_move_ford(mot_la);
			rps_move_ford(mot_ra);
			
		}
		
	}
	else if( moto_set==2   )
	{
		if( moto_set_last != 2 )
		{
			sprintf(buff, "> move back");
			ax_alert(buff);
		
			//rps_move_speed(rps_move_inisp);
			
			rps_move_back(mot_la);
			rps_move_back(mot_ra);
			
		}
	}
	
	if( ( moto_set == 1 || moto_set == 2 ) )
	{
		if(ax_sett_forcemode == 1)
		{
			if( moto_set == moto_go_last )
			{
		
		
				uint8_t nspeed = 0 ;
			
				if(moto_go_speed < rps_move_inisp )
					nspeed = rps_move_inisp ;
				else
				{
				
					if( moto_go_speed > rps_move_max )
						nspeed = rps_move_max ;
					else // if (roto_set == 0 )
						nspeed = moto_go_speed + 1 ;
						
					
				}
			
				
				rps_move_aspeed(nspeed);
				
				
				moto_go_speed = nspeed ;
			
				//sprintf(buff, ">> speed %u",nspeed);
				//	ax_alert(buff);
				//delay(100);
			
			}
			else if(moto_set != moto_set_last)
			{
				moto_go_speed = rps_move_inisp ;
				rps_move_aspeed(rps_move_inisp);
				
				
			}
			
		}
		else if(ax_sett_forcemode == 0 )
		{
				uint8_t nspeed = 0 ;
				
				if (roto_set == 0 )
					nspeed = 120 ;
				else
					nspeed = 150 ;
			
				
				rps_move_aspeed(nspeed);
				moto_go_speed = nspeed ;
			
			
		}
	
	}
	
	
	if(moto_set==0)
	{
	
		if( moto_set_last != 0 )
		{
			sprintf(buff, "> move none");
			ax_alert(buff);
		
			//rps_move_speed(rps_move_inisp);
			
			rps_move_none(mot_la);
			rps_move_none(mot_ra);
			
		}
		else
		{
		
			if( moto_go_speed > 20 )
				moto_go_speed-=10 ;
				
		}
		
	}
	else
		moto_go_last = moto_set ;
		
		
	moto_set_last = moto_set ;
	
	
	
	
	
	
	
	if( roto_set==0 )
	{
		
		if( roto_set_last != 0 )
		{
			sprintf(buff, "> roto none");
			ax_alert(buff);
		
			//rps_move_speed(rps_move_inisp);
			ser_l.write(ser_l_off + 90);
			ser_r.write(ser_r_off + 90);
			
		}
	}
	else if( roto_set==1   )
	{
		if( roto_set_last != 1 )
		{
			sprintf(buff, "> roto left");
			ax_alert(buff);
		
			//rps_move_speed(rps_move_inisp);
			ser_l.write(ser_l_off + 60);
			ser_r.write(ser_r_off + 75);
			
			
		}
		
	}
	else if( roto_set==2   )
	{
		if( roto_set_last != 2 )
		{
			sprintf(buff, "> roto right");
			ax_alert(buff);
		
			//rps_move_speed(rps_move_inisp);
			ser_l.write(ser_l_off + 105);
			ser_r.write(ser_r_off + 120);
			
			
		}
	}
	
	roto_set_last = roto_set ;
	
	
	
	
	
	
	if( troto_set==0 )
	{
		
		if( troto_set_last != 0 )
		{
			sprintf(buff, "> tbase none");
			ax_alert(buff);
		
			rps_move_break(mot_tbase);
			//rps_move_speed(mot_tbase,255);
	
		}
	}
	else if( troto_set==1   )
	{
		if( troto_set_last != 1 )
		{
			sprintf(buff, "> tbase left");
			ax_alert(buff);
			
			rps_move_back(mot_tbase);
			rps_move_speed(mot_tbase,mot_tbase_inisp);
			
			
			
		}
		
	}
	else if( troto_set==2   )
	{
		if( troto_set_last != 2 )
		{
			sprintf(buff, "> tbase right");
			ax_alert(buff);
		
			rps_move_ford(mot_tbase);
			rps_move_speed(mot_tbase,mot_tbase_inisp);
			
			
			
		}
	}
	
	troto_set_last = troto_set ;
	
	
	
	if( ttroto_set==0 )
	{
		
		if( ttroto_set_last != 0 )
		{
			sprintf(buff, "> ttpop none");
			ax_alert(buff);
		
		}
	}
	else if( ttroto_set==1   )
	{
		if( ttroto_set_last != 1 )
		{
			sprintf(buff, "> ttop up");
			ax_alert(buff);
			
		}
		
		
		int16_t npos ;
		npos = ser_ttop_cur - 1 ;
		if(npos < 0)
			npos = 0 ;
		ser_ttop_write(npos);
		
	}
	else if( ttroto_set==2   )
	{
		if( ttroto_set_last != 2 )
		{
			sprintf(buff, "> ttop down");
			ax_alert(buff);
			
			
		}
		
		
		int16_t npos ;
		npos = ser_ttop_cur + 1 ;
		if(npos > 180)
			npos = 180 ;
		ser_ttop_write(npos);
		
	}
	ser_ttop_write(ser_ttop_cur);
	ttroto_set_last = ttroto_set ;
	
	
	if( mspin_set == 0 && moto_set == 0)
	{
		rps_move_none(mot_la);
		rps_move_none(mot_ra);
		
		//rps_move_speed(mot_la,0);
		//rps_move_speed(mot_ra,0);
		
	}
	else if( mspin_set == 0 && roto_set == 0)
	{
		
		ser_l.write(ser_l_off + 90);
		ser_r.write(ser_r_off + 90);
		
	}
	else if( mspin_set == 1 )
	{
		rps_move_back(mot_la);
		rps_move_ford(mot_ra);
		
		
		rps_move_speed(mot_la,150);
		rps_move_speed(mot_ra,140);
		
		ser_l.write(ser_l_off + 150);
		ser_r.write(ser_r_off + 60);
		
		
	}
	
	else if( mspin_set == 2 )
	{
		rps_move_back(mot_ra);
		rps_move_ford(mot_la);
		
		
		rps_move_speed(mot_la,150);
		rps_move_speed(mot_ra,150);
		
		
		ser_l.write(ser_l_off + 120);
		ser_r.write(ser_r_off + 60);
		
		
	}
		
	
	

}

void rps_move_ford(struct motor_c_st &mot)
{

	
    digitalWrite(mot.in1, LOW);
    digitalWrite(mot.in2, HIGH); 
	mot.motion = 1 ;

}


void rps_move_back(struct motor_c_st &mot)
{

	
    digitalWrite(mot.in1, HIGH);
    digitalWrite(mot.in2, LOW); 
	mot.motion = 2 ;

}


void rps_move_none(struct motor_c_st &mot)
{

	
    digitalWrite(mot.in1, LOW);
    digitalWrite(mot.in2, LOW); 
	rps_move_speed(mot , 0 );
	mot.motion = 0 ;

}


void rps_move_break(struct motor_c_st &mot)
{

	
    digitalWrite(mot.in1, HIGH);
    digitalWrite(mot.in2, HIGH);
    rps_move_speed( mot ,255 );
    
    mot.motion = 3 ;


}


void rps_move_speed(struct motor_c_st &mot ,uint8_t speed)
{
	mot.speed = speed ;

	analogWrite(mot.pwm, speed );


}



void ax_alert(char * str)
{

	if(ax_sett_verbose == 1)
	{
  		Serial.println(str);
  		BT.println(str);
  	}


}




