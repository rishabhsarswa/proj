
#include <Arduino.h>
#include <Servo.h>
#include <SoftwareSerial.h>



// ------------------------------------------





void ax_help();
void ax_alert(char * str);

char ax_get_ipos(char state);

void rps_loop_key();






// -------------------------------------------






//SoftwareSerial BT(0, 1);


char buff[128]={0};

SoftwareSerial BT(A0, A1);





// --------------

struct ax_kv_st
{


char c;
char val ;
char lval ;

long int millis;



};
char ax_kv_total = 32 ;
struct ax_kv_st ax_kv[32];




#include "rps_pis.h"



void rps_setup_key()
{


	Serial.begin(9600);
	BT.begin(9600);
	
	
	sprintf(buff, "Booting RPS ... ");
	ax_alert(buff);
	//ax_alert("Booting RPS ... ");
	
	
	for( uint8_t i = 0 ; i <= 254 ; i++ )
	{
		char ipos = ax_get_ipos(i);
		if(ipos > 0)
		{
			ax_kv[ipos].c=i;
			ax_kv[ipos].val=2;
			ax_kv[ipos].lval=2;
			ax_kv[ipos].millis=0;
			
		}
	
	}
	
	
	sprintf(buff, "RPS Prepairing ... ");
	ax_alert(buff);
	
}

void rps_setup()
{
	rps_setup_key();
	rps_pis_setup();

}
char ax_looped = 0 ;
char ax_helped = 0 ;


void rps_loop()
{
	rps_loop_key();
	rps_pis_loop();
	rps_pis_autocontrol();
	
	
}

void rps_loop_key()
{

	if(ax_looped == 0)
	{
		ax_looped = 1 ;
		sprintf(buff, "RPS Ready ... done ");
		ax_alert(buff);
	}
	for(char i = 0 ; i < ax_kv_total ; i++ )
	{
		ax_kv[i].lval = ax_kv[i].val ;
	}
	
	char state = 0 ;
	
	if(BT.available() > 0)
	{    
		state = BT.read();
		if(state == 's')
		{
			delay(10);
			if(BT.available() > 0)
			{
				state = BT.read();
				if(state == 'e')
				{
					delay(10);
					if(BT.available() > 0)
					{
						state = BT.read();
						delay(10);
						if(BT.available() > 0)
						{
							char state2 = BT.read();
							
								char ipos = ax_get_ipos(state) ;
								if( ax_kv[ipos].val != state2 )
								{
									// state = button ascii code , 
									// state2 = 1 : pressed ; 2 :released ;
									sprintf(buff, "v:%c:%d;",state , state2 );
									ax_alert(buff);
								
								
								}
								
								
								//ax_kv[ipos].lval=ax_kv[ipos].val;
								
								ax_kv[ipos].val=state2;
								
								ax_kv[ipos].millis=millis();
																	
							
						}
			
					}
			
				}
			}
		}
		else
		{
			sprintf(buff, "??:%d;",state );
			ax_alert(buff);
		}
		
	}
	
	
	long int cmils = millis();
	for(char i = 0 ; i < ax_kv_total ; i++ )
	{
		
		if( ax_kv[i].val == 1 && ( cmils - ax_kv[i].millis ) > 2400 )
		{
			
			ax_kv[i].val = 2 ;
			sprintf(buff, "?^:%c:2;", ax_kv[i].c );
			ax_alert(buff);
			
				
		}
		//delay(10);
		
		
	}
	
	char ipos = ax_get_ipos('h') ;
	if( ax_kv[ipos].val == 1 && ax_kv[ipos].lval == 2  )
	{
		sprintf(buff, "> connected --");
		//  Robotic Pesticide Sprayer\n\n\tkeys\ttask\n\th\tprint help(this message)\n\n");
		BT.println(buff);
		
		//sprintf(buff, "\t w\trun forward\n");
		//ax_alert(buff);
		
		//ax_kv[ipos].lval = 1 ;		
	
	}
	if( ax_kv[ipos].val == 2 && ax_kv[ipos].lval == 1  )
	{
		//sprintf(buff, "------- HELP ---------\n  Robotic Pesticide Sprayer \n------------------\n");
		//ax_alert(buff);
		//ax_kv[ipos].lval = 2 ;		
	
	}
	
	
	

}


void ax_help()
{
  //BT.println("press 'h' for help");
  BT.println("-----------help----------------");

}

char ax_get_ipos(char state)
{
	
			char ipos=0 ;
				switch(state)
				{
							case 'w' :
								ipos=1;
								break ;
							case 'x' :
								ipos=2;
								break ;
							case 'a' :
								ipos=3;
								break ;
							case 'd' :
								ipos=4;
								break ;
							case 's' :
								ipos=5;
								break ;
								
							case 'r' :
								ipos=6;
								break ;
							case 't' :
								ipos=7;
								break ;
							case 'y' :
								ipos=8;
								break ;
							case 'u' :
								ipos=9;
								break ;
							
							
							case 'h' :
								ipos=10;
								break ;
	
							case 'f' :
								ipos=11;//for force mode
								break ;
							
							case 'v' :
								ipos=12;//for verbose
								break ;
							
							
							
							case 'g' :
								ipos=13;//for w,s grab
								break ;
								
							
							case 'p' :
								ipos=14;//for pump toggle
								break ;
							
							
							case 'l' :
								ipos=15;//for pump lock
								break ;
							
							
							
							
							case 'q' :
								ipos=16;//for spin
								break ;
							case 'e' :
								ipos=17;//for spin
								break ;
							
							
							
							
								
							default :
								ipos=0 ;
								break ;
						
				};
		return ipos ;
}




