

// windows patch.h



void ax_open_btserial()
{

	
	printf("-- open bluetoooth -- \n ");
	

}

void ax_wr_bt(char c,char data)
{
	char buff[8] ={0};
	buff[0]='s';
	buff[1]='e';
	buff[2]=c;
	buff[3]=data;
	buff[4]=0;
	
	
	//sprintf(buff ,"echo -n '%c' >> /dev/rfcomm0", c );
	//printf("writing '%c'\n",c);
	
	//int out = 
	
	printf("writing --- %c,%c,%c,%d;\n",buff[0],buff[1],buff[2],buff[3]);
	
	
	//usleep(100);
	//serialPort.Write(buff);
	gettimeofday(&((axm).last_send) , NULL );
				
	//printf("->%d;\n",out);
	usleep(100);
}




void ax_close_btserial()
{

	
	printf("-- close bluetoooth -- \n ");
	

}














