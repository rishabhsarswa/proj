

#include <stdio.h>
#include <stdlib.h>


#include <sys/time.h>
#include <unistd.h>
//--------------------------


void ax_wr_bt(char c,char data);
void ax_open_btserial();
void ax_close_btserial();
char ax_get_ipos(char state);




//--------------------------


struct ax_main_st
{

	
	struct timeval last_send ;


};

struct ax_main_st axm ;




struct ax_keyst
{

	int xcode ;
	char scode ;
	int is_actd ;
	
	int ev_ac ;
	
	
	struct timeval sact ; // last send time
	struct timeval lact ; // last local data
	struct timeval cact ;

	char exit_send_remain ;
	//struct timeval sact ;
	//struct timeval lact ;

};

char axk_total = 32 ;
struct ax_keyst axk[32] ;


/*
struct ax_keyst axk_w;
struct ax_keyst axk_x;
struct ax_keyst axk_a;
struct ax_keyst axk_d;
struct ax_keyst axk_s;


struct ax_keyst axk_r;
struct ax_keyst axk_t;
struct ax_keyst axk_y;
struct ax_keyst axk_u;

struct ax_keyst axk_h;
*/

//-----------------




void ax_ikey( char xcode , char scode , char ipos )
{
	//char ipos = ax_get_ipos(scode);
	axk[ipos].xcode = xcode ;
	axk[ipos].scode = scode ;
	axk[ipos].is_actd = 0 ;
	axk[ipos].exit_send_remain = 0 ;
	
}

char ax_setuped_v = 0 ;
void ax_setuped()
{
	
	
	
	
	ax_setuped_v = 1 ;
}

void ax_setup()
{



	
	for(char i = 0 ; i < axk_total ; i++ )
	{
		ax_ikey(0,0,i);
	}

	
	ax_ikey(25,'w',ax_get_ipos('w'));//w key
	ax_ikey(53,'x',ax_get_ipos('x'));//x key
	ax_ikey(38,'a',ax_get_ipos('a'));//a key
	ax_ikey(40,'d',ax_get_ipos('d'));//d key
	ax_ikey(39,'s',ax_get_ipos('s'));//s key
	
	ax_ikey(112,'r',ax_get_ipos('r'));
	ax_ikey(117,'t',ax_get_ipos('t'));
	ax_ikey(18,'y',ax_get_ipos('y'));
	ax_ikey(19,'u',ax_get_ipos('u'));
	
	
	ax_ikey(43,'h',ax_get_ipos('h'));
	ax_ikey(41,'f',ax_get_ipos('f'));
	
	ax_ikey(55,'v',ax_get_ipos('v'));
	
	
	ax_ikey(42,'g',ax_get_ipos('g'));
	ax_ikey(33,'p',ax_get_ipos('p'));
	ax_ikey(56,'l',ax_get_ipos('l'));
	
	
	ax_ikey(24,'q',ax_get_ipos('q'));
	ax_ikey(26,'e',ax_get_ipos('e'));

	
	
	ax_open_btserial();
	
	//usleep(2000000);
	
	
	//asking for help
	ax_wr_bt('h',1);
	usleep(100000);
	ax_wr_bt('h',2);
	
	//usleep(1000000);

	
}
void ax_crush()
{

	ax_close_btserial();
	
}

//char ax_ikey_autoreset_pending = 0 ;
void ax_ikey_autoreset(struct ax_keyst &atd)
{



	if(atd.is_actd == 1 && atd.ev_ac == 0 )
	{
			struct timeval rtd;     			
      			gettimeofday(&(rtd) , NULL );
      			long ppsec = rtd.tv_sec - (atd).lact.tv_sec ;
      			long ppusec = ppsec*1000000 + rtd.tv_usec - (atd).lact.tv_usec ;
      			
      			
      			//long tpsec = rtd.tv_sec - (atd).sact.tv_sec ;
      			//long tpusec = tpsec*1000000 + rtd.tv_usec - (atd).sact.tv_usec ;
      			
      			
      			
      			if( ppusec > 510 )
      			{
	      			//printf(">up:%d; total:%ld; after:%ld; \n" , atd.xcode ,tpusec, ppusec ) ;
				printf("^:%c; \n" , atd.scode ) ;
				atd.is_actd = 0 ;
				atd.exit_send_remain = 4 ; // wii send exit code 2 time again for better response
				//ax_wr_bt((atd).scode, 2 );
				//ax_wr_bt('s');
			}
	}
}

void ax_ikey_autosend()
{

	struct timeval rtd;     			
	gettimeofday(&(rtd) , NULL );
      	
      	long plpsec = rtd.tv_sec - (axm.last_send).tv_sec ;
      	long plpusec = plpsec*1000000 + rtd.tv_usec - (axm.last_send).tv_usec ;
      	
      	
      	if(plpusec < 100000)
      		return ;
      	
      			

	char ipos_max = 0 ;
	long usec_max = 0 ;
	
	for(char i = 0 ; i < axk_total ; i++ )
	{
	
		struct ax_keyst &atd = axk[i];
		if( ( atd.is_actd == 1 ) || ( atd.exit_send_remain > 0 ) )
		{
			long ppsec = rtd.tv_sec - (atd).sact.tv_sec ;
      			long ppusec = ppsec*1000000 + rtd.tv_usec - (atd).sact.tv_usec ;
      			
      			if( ppusec >= usec_max )
      			{
      				if( atd.exit_send_remain > 0 )
				{
      					usec_max = ppusec ;
      					ipos_max = i ;
      				}
      				else if( ppusec > 1000000 )
      				{
      					usec_max = ppusec ;
      					ipos_max = i ;
      				}
      			}
      			//printf("---%d:%ld\n", i , ppusec );
      			
      		}
      	}
			
			
			
				if( ipos_max > 0  )
      				{
      					//printf(">up:%d; total:%ld; after:%ld; \n" , atd.xcode ,tpusec, ppusec ) ;
					//printf("=:%c; \n" , atd.scode ) ;
					
					
					if(axk[ipos_max].is_actd == 1 )
					{
						ax_wr_bt((axk[ipos_max]).scode, 1 );
						//printf("=V:%c;\n",axk[ipos_max].scode);
	      					
	      					if( axk[ipos_max].exit_send_remain > 0 )
	      						axk[ipos_max].exit_send_remain-- ;
	      				
					}
					else if(axk[ipos_max].exit_send_remain > 0 )
					{
						ax_wr_bt((axk[ipos_max]).scode, 2 );
						//printf("=^:%c;\n",axk[ipos_max].scode);
						axk[ipos_max].exit_send_remain-- ;
	      					
					}
					
					
					gettimeofday(&((axk[ipos_max]).sact) , NULL );
				
					//ax_ikey_autoreset_pending = 0 ;
					//ax_wr_bt('s');
				}
			
	
	
	
      	if(plpusec > 5000000)
      	{
      	
		//asking for help
		ax_wr_bt('z',1);
		usleep(100000);
		ax_wr_bt('z',2);
	
      	}    	
	
	
	
}


void ax_loop()
{


	if(ax_setuped_v == 0)
	{
		ax_setuped();
		ax_setuped_v = 1 ;
	}
	for(char i = 0 ; i < axk_total ; i++ )
	{
	
		ax_ikey_autoreset(axk[i]);
	
	}
	ax_ikey_autosend();

	usleep(100);

}




struct ax_keyst* ax_get_axk(int xcode)
{
	
	struct ax_keyst *atd = 0 ;
	
	//switch(keysym)
	switch(xcode)
	{
		case 25 : //w
			
			atd=&axk[ax_get_ipos('w')] ;
			break;
		
		case 53 : //x
			
			atd=&axk[ax_get_ipos('s')] ;
			break;
		
		case 38 : //a
			
			atd=&axk[ax_get_ipos('a')] ;
			break;
		
		case 40 : //d
			
			atd=&axk[ax_get_ipos('d')] ;
			break;
		
		case 39 : //s
			
			atd=&axk[ax_get_ipos('x')] ;
			break;
		
		//arrow controls
		case 111 : // up
			
			atd=&axk[ax_get_ipos('r')] ;
			break;
		
		case 116 : //down
			
			atd=&axk[ax_get_ipos('t')] ;
			break;
		
		case 113 : //left
			
			atd=&axk[ax_get_ipos('a')] ;
			break;
		
		case 114 : //right
			
			atd=&axk[ax_get_ipos('d')] ;
			break;
		
		case 65 : //space
			
			atd=&axk[ax_get_ipos('s')] ;
			break;
		
		
		case 112 : //pageup
			
			atd=&axk[ax_get_ipos('y')] ;
			break;
		
		
		case 117 : //padedown
			
			atd=&axk[ax_get_ipos('u')] ;
			break;
		
		
		case 18 : //9
			
			atd=&axk[ax_get_ipos('r')] ;
			break;
		
		
		case 19 : //0
			
			atd=&axk[ax_get_ipos('t')] ;
			break;
		
		
		case 43 : //h
			
			atd=&axk[ax_get_ipos('h')] ;
			break;
		
		case 41 : //f
			
			atd=&axk[ax_get_ipos('f')] ;
			break;
		
		case 55 : //v
			
			atd=&axk[ax_get_ipos('v')] ;
			break;
		
		
		
		case 42 : //g
			
			atd=&axk[ax_get_ipos('g')] ;
			break;
		case 33 : //p
			
			atd=&axk[ax_get_ipos('p')] ;
			break;
		case 46 : //l
			
			atd=&axk[ax_get_ipos('l')] ;
			break;
		
		
		case 27 : //r
			
			atd=&axk[ax_get_ipos('r')] ;
			break;
		case 28 : //t
			
			atd=&axk[ax_get_ipos('t')] ;
			break;
		case 29 : //y
			
			atd=&axk[ax_get_ipos('y')] ;
			break;
		case 30 : //u
			
			atd=&axk[ax_get_ipos('u')] ;
			break;
		
		case 24 : //q
			
			atd=&axk[ax_get_ipos('q')] ;
			break;
		case 26 : //e
			
			atd=&axk[ax_get_ipos('e')] ;
			break;
		
		
		default :
			
			return 0 ;
			
			break ;
		
      
  	};
  	
  	
  	return atd ;
}






char ax_get_ipos(char state)
{
	
			char ipos=0 ;
				switch(state)
				{
							case 'w' :
								ipos=1;
								break ;
							case 'x' :
								ipos=2;
								break ;
							case 'a' :
								ipos=3;
								break ;
							case 'd' :
								ipos=4;
								break ;
							case 's' :
								ipos=5;
								break ;
								
							case 'r' :
								ipos=6;
								break ;
							case 't' :
								ipos=7;
								break ;
							case 'y' :
								ipos=8;
								break ;
							case 'u' :
								ipos=9;
								break ;
							
							
							case 'h' :
								ipos=10;
								break ;
							
							
							case 'f' :
								ipos=11;
								break ;
							
							
							case 'v' :
								ipos=12;
								break ;
								
								
								
								
								
							
							case 'g' :
								ipos=13;//for w,s grab
								break ;
								
							
							case 'p' :
								ipos=14;//for pump toggle
								break ;
							
							
							case 'l' :
								ipos=15;//for pump lock
								break ;
							
							
							case 'q' :
								ipos=16;//for spin
								break ;
							case 'e' :
								ipos=17;//for spin
								break ;
							
								
								
								
							default :
								ipos=0 ;
								break ;
						
				};
		return ipos ;
}






struct ax_keyst* ax_get_axk_ascii(int xcode)
{


	//printf("searching %d;\n",xcode);
	
	struct ax_keyst *atd = 0 ;
	
	//switch(keysym)
	switch(xcode)
	{
		case 119 : //w
			
			atd=&axk[ax_get_ipos('w')] ;
			break;
		
		case 120 : //x
			
			atd=&axk[ax_get_ipos('s')] ;
			break;
		
		case 97 : //a
			
			atd=&axk[ax_get_ipos('a')] ;
			break;
		
		case 100 : //d
			
			atd=&axk[ax_get_ipos('d')] ;
			break;
		
		case 115 : //s
			
			atd=&axk[ax_get_ipos('x')] ;
			break;
		
		
		case 32 : //space
			
			atd=&axk[ax_get_ipos('s')] ;
			break;
		
		
		
		case 57 : //9
			
			atd=&axk[ax_get_ipos('r')] ;
			break;
		
		
		case 48 : //0
			
			atd=&axk[ax_get_ipos('t')] ;
			break;
		
		
		case 104 : //h
			
			atd=&axk[ax_get_ipos('h')] ;
			break;
		
		case 102 : //f
			
			atd=&axk[ax_get_ipos('f')] ;
			break;
		
		case 118 : //v
			
			atd=&axk[ax_get_ipos('v')] ;
			break;
		
		
		
		case 103 : //g
			
			atd=&axk[ax_get_ipos('g')] ;
			break;
		case 112 : //p
			
			atd=&axk[ax_get_ipos('p')] ;
			break;
		case 108 : //l
			
			atd=&axk[ax_get_ipos('l')] ;
			break;
		
		
		case 114 : //r
			
			atd=&axk[ax_get_ipos('r')] ;
			break;
		case 116 : //t
			
			atd=&axk[ax_get_ipos('t')] ;
			break;
		case 121 : //y
			
			atd=&axk[ax_get_ipos('y')] ;
			break;
		case 117 : //u
			
			atd=&axk[ax_get_ipos('u')] ;
			break;
		
		case 113 : //q
			
			atd=&axk[ax_get_ipos('q')] ;
			break;
		case 101 : //e
			
			atd=&axk[ax_get_ipos('e')] ;
			break;
		
		
		default :
			
			return 0 ;
			
			break ;
		
      
  	};
  	
  	
  	return atd ;
}





