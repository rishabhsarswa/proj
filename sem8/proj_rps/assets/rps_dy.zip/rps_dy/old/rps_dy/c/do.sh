#!/bin/bash


function su_r()
{

	rfcomm bind rfcomm0 00:20:12:08:07:AF
	sleep 1
	chmod 777 /dev/rfcomm0

}


if [[ $1 == 'fn' ]] ;
then

	$2
fi


if [[ $1 == 'su' ]] ;
then
	echo "enter super user password "
        su -c "$0 fn su_r"
fi



# cu -l /dev/rfcomm0 -s 115200



