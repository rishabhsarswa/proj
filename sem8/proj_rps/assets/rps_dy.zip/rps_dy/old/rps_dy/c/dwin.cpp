
// Keyboard / mouse input without interrupting the flow

#include <windows.h>


#include "mkeyl.h"
#include "patch_win.h"



int main()
{


	printf("welcome to RPS  \n");
    HANDLE hIn;
    HANDLE hOut;

    bool Continue = TRUE;
    int KeyEvents = 0;
    int MouseEvents = 0;
    INPUT_RECORD InRec;
    DWORD NumRead;

    hIn = GetStdHandle(STD_INPUT_HANDLE);
    hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    
    

    //cout << "Key Events   : " << endl;
    //cout << "Mouse Events : " << flush;
	printf("loading ... \n");

	
	ax_setup();	
	

    while (Continue)
    {

	//printf(".\n");
	
        ax_loop();
	GetNumberOfConsoleInputEvents(hIn, &NumRead) ;
        if( NumRead > 0  )
        {
        	//printf("..%d;\n",NumRead);
        	//ReadConsoleInput(hIn, &InRec, 1, &NumRead);
		ReadConsoleInput(hIn, &InRec, 1, &NumRead);
		
		//GetNumberOfConsoleInputEvents(hIn, &InRec, 1, &NumRead);


	        if(InRec.EventType  == KEY_EVENT)
	        {
        
			//printf("key c:%d;s:%d; \n" , InRec.Event.KeyEvent.uChar.AsciiChar , InRec.Event.KeyEvent.bKeyDown );




		
			struct ax_keyst *atd = ax_get_axk_ascii(InRec.Event.KeyEvent.uChar.AsciiChar);
			if(atd)
			{

	    	    		/* keyboard events */
    	    
	    	    		if (InRec.Event.KeyEvent.bKeyDown == 1)
	    	    		{
    	    		
					if( (*atd).is_actd == 0 )
					{
						printf( "v:%c;\n", (*atd).scode );
						(*atd).exit_send_remain = 4 ;
						//ax_wr_bt((*atd).scode, 1 );
						//gettimeofday(&((*atd).sact) , NULL );
						gettimeofday(&((*atd).lact) , NULL );	
						(*atd).is_actd = 1 ;
						(*atd).ev_ac = 1 ;
					
					}	
	    	        		//gettimeofday(&((*atd).lact) , NULL );
	    	        
	    	        		
					
			
			
	    	        		
	    	    		}
	    	    		else if (InRec.Event.KeyEvent.bKeyDown == 0)
	    	    		{
	    	    	
	    	    			//gettimeofday(&((*atd).cact) , NULL );
	    	        		//long ppsec = (*atd).cact.tv_sec - (*atd).lact.tv_sec ;
	    	        		//long ppusec = ppsec*1000000 + (*atd).cact.tv_usec - (*atd).lact.tv_usec ;
	    	        		//printf( "^:%x;usec:%ld;\n", event.xkey.keycode , ppusec );
	    	        		
	    	        		//printf( "^:%x;\n", event.xkey.keycode );         
	    	        		gettimeofday(&((*atd).lact) , NULL );
	    	        		
	    	        		(*atd).ev_ac = 0 ;
					
	    	        		
	    	    		}
	    	    	}
	    	    	else
	    	    	{
	    	    		printf("key c:%d;s:%d; \n" , InRec.Event.KeyEvent.uChar.AsciiChar , InRec.Event.KeyEvent.bKeyDown );

	    	    	}
	    	    	//FlushConsoleInputBuffer(hIn);
	    	    	//fflush(stdin);
	    	}
	
	
        }
        //usleep(10000);
    }
    ax_crush();

    return 0;
}
