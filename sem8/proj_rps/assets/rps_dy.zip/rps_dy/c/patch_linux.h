

// linux patch.h


#include <CppLinuxSerial/SerialPort.hpp>

using namespace mn::CppLinuxSerial;



//SerialPort serialPort;
SerialPort serialPort("/dev/rfcomm0", 115200);


void ax_open_btserial()
{

	
	printf("trying to open /dev/rfcomm0 \n ");
	serialPort.SetTimeout(-1); // Block when reading until any data is received
	serialPort.Open();
	printf("done\n");
	
	
	//system("xfce4-terminal --hide-toolbar -e \"./btreader.sh\" &");
	//system("xfce4-terminal --hide-toolbar -e \"cat /dev/rfcomm0\" &");
	
	//usleep(1000000);
	

}

void ax_wr_bt(char c,char data)
{
	char buff[8] ={0};
	buff[0]='s';
	buff[1]='e';
	buff[2]=c;
	buff[3]=data;
	buff[4]=0;
	
	
	//sprintf(buff ,"echo -n '%c' >> /dev/rfcomm0", c );
	//printf("writing '%c'\n",c);
	
	//int out = 
	
	serialPort.Write(buff);
	//usleep(100);
	//serialPort.Write(buff);
	gettimeofday(&((axm).last_send) , NULL );
				
	//printf("->%d;\n",out);
	usleep(100);
}





void ax_close_btserial()
{

	
	serialPort.Close();
	system("kill `cat bt*pid`");
	
}











